(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9e62b80a._.js",
  "static/chunks/src_bbb90d96._.js"
],
    source: "dynamic"
});
