(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d16dab7a._.js",
  "static/chunks/src_7705b641._.js"
],
    source: "dynamic"
});
