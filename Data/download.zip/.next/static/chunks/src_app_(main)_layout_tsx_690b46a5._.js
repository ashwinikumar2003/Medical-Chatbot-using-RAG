(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_2ef296f3._.js",
  "static/chunks/src_components_a342cc45._.js"
],
    source: "dynamic"
});
