(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0ae41d1f._.js",
  "static/chunks/src_eea3e91e._.js"
],
    source: "dynamic"
});
