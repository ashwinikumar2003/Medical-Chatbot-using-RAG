module.exports = {

"[project]/.next-internal/server/app/(main)/products/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/(main)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(main)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/components/product/product-card.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/product/product-card.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/product/product-card.tsx <module evaluation>", "default");
}}),
"[project]/src/components/product/product-card.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/product/product-card.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/product/product-card.tsx", "default");
}}),
"[project]/src/components/product/product-card.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$product$2d$card$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/product/product-card.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$product$2d$card$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/src/components/product/product-card.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$product$2d$card$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/src/lib/data.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "categories": (()=>categories),
    "getProduct": (()=>getProduct),
    "getProducts": (()=>getProducts),
    "products": (()=>products)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$armchair$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Armchair$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/armchair.js [app-rsc] (ecmascript) <export default as Armchair>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Lamp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/lamp.js [app-rsc] (ecmascript) <export default as Lamp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-grid.js [app-rsc] (ecmascript) <export default as LayoutGrid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$speaker$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Speaker$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/speaker.js [app-rsc] (ecmascript) <export default as Speaker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book.js [app-rsc] (ecmascript) <export default as Book>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shirt$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Shirt$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shirt.js [app-rsc] (ecmascript) <export default as Shirt>");
;
const categories = [
    {
        id: 'furniture',
        name: 'Furniture',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$armchair$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Armchair$3e$__["Armchair"]
    },
    {
        id: 'lighting',
        name: 'Lighting',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Lamp$3e$__["Lamp"]
    },
    {
        id: 'tech',
        name: 'Tech',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$speaker$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Speaker$3e$__["Speaker"]
    },
    {
        id: 'decor',
        name: 'Decor',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
    },
    {
        id: 'books',
        name: 'Books',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__["Book"]
    },
    {
        id: 'apparel',
        name: 'Apparel',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shirt$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Shirt$3e$__["Shirt"]
    }
];
const products = [
    {
        id: '1',
        name: 'Minimalist Wooden Chair',
        description: 'Experience comfort and style with this minimalist wooden chair. Crafted from sustainably sourced oak, its clean lines and natural finish bring a touch of Scandinavian design to any room. Perfect for dining rooms, offices, or as an accent piece.',
        price: 129.99,
        rating: 4.5,
        category: 'furniture',
        imageId: 'prod-1'
    },
    {
        id: '2',
        name: 'Modern Ceramic Vase',
        description: 'A sleek, modern ceramic vase that adds an elegant touch to your decor. Its matte finish and sculptural form make it a statement piece, with or without flowers. Ideal for mantels, shelves, or centerpieces.',
        price: 49.99,
        rating: 4.8,
        category: 'decor',
        imageId: 'prod-2'
    },
    {
        id: '3',
        name: 'Geometric Cushions (Set of 2)',
        description: 'Liven up your space with this set of two geometric-patterned cushions. Made from a soft but durable cotton-linen blend, they provide both comfort and a modern aesthetic. The cover is removable and machine washable.',
        price: 79.99,
        rating: 4.2,
        category: 'decor',
        imageId: 'prod-3'
    },
    {
        id: '4',
        name: 'Industrial Desk Lamp',
        description: 'Illuminate your workspace with this stylish desk lamp. Featuring an adjustable arm and a weighted base, its industrial design combines form and function. The matte black finish complements any modern or classic desk setup.',
        price: 89.99,
        rating: 4.6,
        category: 'lighting',
        imageId: 'prod-4'
    },
    {
        id: '5',
        name: 'Potted Succulents Trio',
        description: 'Bring a touch of nature indoors with this collection of three small succulent plants. Housed in minimalist concrete pots, these low-maintenance plants are perfect for brightening up a desk, windowsill, or shelf.',
        price: 39.99,
        rating: 4.9,
        category: 'decor',
        imageId: 'prod-5'
    },
    {
        id: '6',
        name: 'Textured Throw Blanket',
        description: 'Cozy up with this beautifully textured throw blanket. Woven from 100% cotton, it\'s soft, breathable, and perfect for any season. The subtle pattern and tasseled edges add a touch of bohemian chic to your sofa or bed.',
        price: 99.99,
        rating: 4.7,
        category: 'decor',
        imageId: 'prod-6'
    },
    {
        id: '7',
        name: 'Abstract Gold-Framed Art',
        description: 'Elevate your walls with this stunning piece of abstract wall art. The subtle colors and dynamic shapes are highlighted by a slim, elegant gold frame. A sophisticated addition to any living room, bedroom, or hallway.',
        price: 199.99,
        rating: 4.8,
        category: 'decor',
        imageId: 'prod-7'
    },
    {
        id: '8',
        name: 'Minimalist Digital Clock',
        description: 'A modern, minimalist alarm clock that displays time, date, and temperature. Its wooden finish and clean LED display blend seamlessly into any bedroom decor. Features adjustable brightness and a simple, intuitive interface.',
        price: 59.99,
        rating: 4.4,
        category: 'tech',
        imageId: 'prod-8'
    },
    {
        id: '9',
        name: 'Aura-Fi Wireless Speaker',
        description: 'Immerse yourself in rich, 360-degree sound with the Aura-Fi wireless speaker. Its sleek, portable design and long-lasting battery make it perfect for any room or for on-the-go listening. Connects effortlessly via Bluetooth.',
        price: 149.99,
        rating: 4.9,
        category: 'tech',
        imageId: 'prod-9'
    },
    {
        id: '10',
        name: 'Ergo-Flex Office Chair',
        description: 'Upgrade your home office with the Ergo-Flex chair. Designed for all-day comfort, it features a breathable mesh back, adjustable lumbar support, and customizable armrests. Stay productive and comfortable.',
        price: 349.99,
        rating: 4.7,
        category: 'furniture',
        imageId: 'prod-10'
    },
    {
        id: '11',
        name: 'AuraGlow Smart Mug',
        description: 'Never drink cold coffee again. The AuraGlow Smart Mug allows you to set and maintain your preferred drinking temperature for hours. Controlled via a simple app, it\'s the ultimate gift for any hot beverage lover.',
        price: 129.99,
        rating: 4.6,
        category: 'tech',
        imageId: 'prod-11'
    },
    {
        id: '12',
        name: 'AuraSound Headphones',
        description: 'Experience pure, uninterrupted audio with AuraSound noise-cancelling headphones. With plush earcups and up to 30 hours of playtime, they are perfect for travel, work, or simply enjoying your favorite music.',
        price: 299.99,
        rating: 4.8,
        category: 'tech',
        imageId: 'prod-12'
    },
    {
        id: '13',
        name: 'The Art of Design',
        description: 'A beautifully illustrated book exploring the principles of modern design. A perfect coffee table book that inspires and educates.',
        price: 55.00,
        rating: 4.9,
        category: 'books',
        imageId: 'prod-13'
    },
    {
        id: '14',
        name: 'Organic Cotton T-Shirt',
        description: 'A classic, comfortable t-shirt made from 100% organic cotton. Ethically made and incredibly soft, it\'s a staple for any wardrobe.',
        price: 35.00,
        rating: 4.7,
        category: 'apparel',
        imageId: 'prod-14'
    },
    {
        id: '15',
        name: 'Floating Shelf Set',
        description: 'A set of two minimalist floating shelves. Made from solid wood, they provide a stylish and practical storage solution for any wall.',
        price: 65.00,
        rating: 4.6,
        category: 'furniture',
        imageId: 'prod-15'
    },
    {
        id: '16',
        name: 'Smart Garden',
        description: 'Grow your own herbs and small vegetables indoors with this smart garden. It automates watering and lighting for a foolproof gardening experience.',
        price: 199.00,
        rating: 4.8,
        category: 'tech',
        imageId: 'prod-16'
    }
];
function getProduct(id) {
    return products.find((p)=>p.id === id);
}
function getProducts(ids) {
    return products.filter((p)=>ids.includes(p.id));
}
}}),
"[project]/src/app/(main)/products/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ProductsPage),
    "generateMetadata": (()=>generateMetadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/product/product-card.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data.ts [app-rsc] (ecmascript)");
;
;
;
async function generateMetadata({ searchParams }) {
    const categoryId = searchParams.category;
    const category = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["categories"].find((c)=>c.id === categoryId);
    if (category) {
        return {
            title: `${category.name} - AuraFind`,
            description: `Explore products in the ${category.name} category.`
        };
    }
    return {
        title: "All Products - AuraFind",
        description: "Explore our collection of curated products."
    };
}
function ProductsPage({ searchParams }) {
    const categoryId = searchParams.category;
    const filteredProducts = categoryId ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["products"].filter((p)=>p.category === categoryId) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["products"];
    const category = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["categories"].find((c)=>c.id === categoryId);
    const title = category ? category.name : "All Products";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto py-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-headline font-bold mb-8",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/app/(main)/products/page.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8",
                children: filteredProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$product$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        product: product
                    }, product.id, false, {
                        fileName: "[project]/src/app/(main)/products/page.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(main)/products/page.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(main)/products/page.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/app/(main)/products/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(main)/products/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_1e94a1bd._.js.map