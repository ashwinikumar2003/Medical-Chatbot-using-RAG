"use client";

import React, { createContext, useContext, useCallback, ReactNode } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { User, CartItem, Product } from '@/lib/types';
import { useToast } from "@/hooks/use-toast";
import { useRouter } from 'next/navigation';

interface AppContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  getCartTotal: () => number;
  cartCount: number;
  likedItems: string[];
  toggleLike: (productId: string) => void;
  isLiked: (productId: string) => boolean;
  viewedProducts: string[];
  addViewedProduct: (productId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppContextProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const { toast } = useToast();
  const [user, setUser] = useLocalStorage<User | null>('user', null);
  const [cart, setCart] = useLocalStorage<CartItem[]>('cart', []);
  const [likedItems, setLikedItems] = useLocalStorage<string[]>('likedItems', []);
  const [viewedProducts, setViewedProducts] = useLocalStorage<string[]>('viewedProducts', []);

  const login = (userData: User) => {
    setUser(userData);
    router.push('/');
  };

  const logout = () => {
    setUser(null);
    setCart([]);
    setLikedItems([]);
    setViewedProducts([]);
    router.push('/');
  };

  const addToCart = useCallback((product: Product, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { id: product.id, name: product.name, price: product.price, imageId: product.imageId, quantity }];
    });
    toast({
        title: "Added to Cart",
        description: `${product.name} has been added to your cart.`,
    });
  }, [setCart, toast]);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  }, [setCart]);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(prevCart =>
        prevCart.map(item =>
          item.id === productId ? { ...item, quantity } : item
        )
      );
    }
  }, [setCart, removeFromCart]);

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };
  
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);

  const toggleLike = useCallback((productId: string) => {
    setLikedItems(prev => {
        const isLiked = prev.includes(productId);
        if (isLiked) {
            toast({ description: "Removed from your favorites." });
            return prev.filter(id => id !== productId);
        } else {
            toast({ description: "Added to your favorites!" });
            return [...prev, productId];
        }
    });
  }, [setLikedItems, toast]);

  const isLiked = useCallback((productId: string) => {
    return likedItems.includes(productId);
  }, [likedItems]);

  const addViewedProduct = useCallback((productId: string) => {
    setViewedProducts(prev => {
        const newViewed = [productId, ...prev.filter(id => id !== productId)];
        return newViewed.slice(0, 10); // Keep last 10 viewed products
    });
  }, [setViewedProducts]);


  const value = {
    user,
    login,
    logout,
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    getCartTotal,
    cartCount,
    likedItems,
    toggleLike,
    isLiked,
    viewedProducts,
    addViewedProduct,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppContextProvider');
  }
  return context;
}
