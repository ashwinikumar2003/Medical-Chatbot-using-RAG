import type { Product, Category } from './types';
import { PlaceHolderImages } from './placeholder-images';
import { Armchair, Lamp, LayoutGrid, Speaker, Book, Shirt } from 'lucide-react';

export const categories: Category[] = [
  { id: 'furniture', name: 'Furniture', icon: Armchair },
  { id: 'lighting', name: 'Lighting', icon: Lamp },
  { id: 'tech', name: 'Tech', icon: Speaker },
  { id: 'decor', name: 'Decor', icon: LayoutGrid },
  { id: 'books', name: 'Books', icon: Book },
  { id: 'apparel', name: 'Apparel', icon: Shirt },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Minimalist Wooden Chair',
    description: 'Experience comfort and style with this minimalist wooden chair. Crafted from sustainably sourced oak, its clean lines and natural finish bring a touch of Scandinavian design to any room. Perfect for dining rooms, offices, or as an accent piece.',
    price: 129.99,
    rating: 4.5,
    category: 'furniture',
    imageId: 'prod-1',
  },
  {
    id: '2',
    name: 'Modern Ceramic Vase',
    description: 'A sleek, modern ceramic vase that adds an elegant touch to your decor. Its matte finish and sculptural form make it a statement piece, with or without flowers. Ideal for mantels, shelves, or centerpieces.',
    price: 49.99,
    rating: 4.8,
    category: 'decor',
    imageId: 'prod-2',
  },
  {
    id: '3',
    name: 'Geometric Cushions (Set of 2)',
    description: 'Liven up your space with this set of two geometric-patterned cushions. Made from a soft but durable cotton-linen blend, they provide both comfort and a modern aesthetic. The cover is removable and machine washable.',
    price: 79.99,
    rating: 4.2,
    category: 'decor',
    imageId: 'prod-3',
  },
  {
    id: '4',
    name: 'Industrial Desk Lamp',
    description: 'Illuminate your workspace with this stylish desk lamp. Featuring an adjustable arm and a weighted base, its industrial design combines form and function. The matte black finish complements any modern or classic desk setup.',
    price: 89.99,
    rating: 4.6,
    category: 'lighting',
    imageId: 'prod-4',
  },
  {
    id: '5',
    name: 'Potted Succulents Trio',
    description: 'Bring a touch of nature indoors with this collection of three small succulent plants. Housed in minimalist concrete pots, these low-maintenance plants are perfect for brightening up a desk, windowsill, or shelf.',
    price: 39.99,
    rating: 4.9,
    category: 'decor',
    imageId: 'prod-5',
  },
  {
    id: '6',
    name: 'Textured Throw Blanket',
    description: 'Cozy up with this beautifully textured throw blanket. Woven from 100% cotton, it\'s soft, breathable, and perfect for any season. The subtle pattern and tasseled edges add a touch of bohemian chic to your sofa or bed.',
    price: 99.99,
    rating: 4.7,
    category: 'decor',
    imageId: 'prod-6',
  },
  {
    id: '7',
    name: 'Abstract Gold-Framed Art',
    description: 'Elevate your walls with this stunning piece of abstract wall art. The subtle colors and dynamic shapes are highlighted by a slim, elegant gold frame. A sophisticated addition to any living room, bedroom, or hallway.',
    price: 199.99,
    rating: 4.8,
    category: 'decor',
    imageId: 'prod-7',
  },
  {
    id: '8',
    name: 'Minimalist Digital Clock',
    description: 'A modern, minimalist alarm clock that displays time, date, and temperature. Its wooden finish and clean LED display blend seamlessly into any bedroom decor. Features adjustable brightness and a simple, intuitive interface.',
    price: 59.99,
    rating: 4.4,
    category: 'tech',
    imageId: 'prod-8',
  },
  {
    id: '9',
    name: 'Aura-Fi Wireless Speaker',
    description: 'Immerse yourself in rich, 360-degree sound with the Aura-Fi wireless speaker. Its sleek, portable design and long-lasting battery make it perfect for any room or for on-the-go listening. Connects effortlessly via Bluetooth.',
    price: 149.99,
    rating: 4.9,
    category: 'tech',
    imageId: 'prod-9',
  },
  {
    id: '10',
    name: 'Ergo-Flex Office Chair',
    description: 'Upgrade your home office with the Ergo-Flex chair. Designed for all-day comfort, it features a breathable mesh back, adjustable lumbar support, and customizable armrests. Stay productive and comfortable.',
    price: 349.99,
    rating: 4.7,
    category: 'furniture',
    imageId: 'prod-10',
  },
  {
    id: '11',
    name: 'AuraGlow Smart Mug',
    description: 'Never drink cold coffee again. The AuraGlow Smart Mug allows you to set and maintain your preferred drinking temperature for hours. Controlled via a simple app, it\'s the ultimate gift for any hot beverage lover.',
    price: 129.99,
    rating: 4.6,
    category: 'tech',
    imageId: 'prod-11',
  },
  {
    id: '12',
    name: 'AuraSound Headphones',
    description: 'Experience pure, uninterrupted audio with AuraSound noise-cancelling headphones. With plush earcups and up to 30 hours of playtime, they are perfect for travel, work, or simply enjoying your favorite music.',
    price: 299.99,
    rating: 4.8,
    category: 'tech',
    imageId: 'prod-12',
  },
  {
    id: '13',
    name: 'The Art of Design',
    description: 'A beautifully illustrated book exploring the principles of modern design. A perfect coffee table book that inspires and educates.',
    price: 55.00,
    rating: 4.9,
    category: 'books',
    imageId: 'prod-13',
  },
  {
    id: '14',
    name: 'Organic Cotton T-Shirt',
    description: 'A classic, comfortable t-shirt made from 100% organic cotton. Ethically made and incredibly soft, it\'s a staple for any wardrobe.',
    price: 35.00,
    rating: 4.7,
    category: 'apparel',
    imageId: 'prod-14',
  },
  {
    id: '15',
    name: 'Floating Shelf Set',
    description: 'A set of two minimalist floating shelves. Made from solid wood, they provide a stylish and practical storage solution for any wall.',
    price: 65.00,
    rating: 4.6,
    category: 'furniture',
    imageId: 'prod-15',
  },
  {
    id: '16',
    name: 'Smart Garden',
    description: 'Grow your own herbs and small vegetables indoors with this smart garden. It automates watering and lighting for a foolproof gardening experience.',
    price: 199.00,
    rating: 4.8,
    category: 'tech',
    imageId: 'prod-16',
  },
];

export function getProduct(id: string): Product | undefined {
  return products.find(p => p.id === id);
}

export function getProducts(ids: string[]): Product[] {
  return products.filter(p => ids.includes(p.id));
}
