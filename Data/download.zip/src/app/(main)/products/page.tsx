import ProductCard from "@/components/product/product-card";
import { products, categories } from "@/lib/data";

type ProductsPageProps = {
  searchParams: {
    category?: string;
  };
};

export async function generateMetadata({ searchParams }: ProductsPageProps) {
  const categoryId = searchParams.category;
  const category = categories.find((c) => c.id === categoryId);

  if (category) {
    return {
      title: `${category.name} - AuraFind`,
      description: `Explore products in the ${category.name} category.`,
    };
  }

  return {
    title: "All Products - AuraFind",
    description: "Explore our collection of curated products.",
  };
}

export default function ProductsPage({ searchParams }: ProductsPageProps) {
  const categoryId = searchParams.category;
  const filteredProducts = categoryId
    ? products.filter((p) => p.category === categoryId)
    : products;
  
  const category = categories.find((c) => c.id === categoryId);
  const title = category ? category.name : "All Products";

  return (
    <div className="container mx-auto py-12">
      <h1 className="text-4xl font-headline font-bold mb-8">{title}</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
