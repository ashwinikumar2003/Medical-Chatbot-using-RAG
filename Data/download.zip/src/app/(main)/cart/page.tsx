"use client";

import Image from "next/image";
import Link from "next/link";
import { useAppContext } from "@/context/app-context";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Minus, Plus, Trash2, ShoppingCart as ShoppingCartIcon } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import RecommendationCarousel from "@/components/product/recommendation-carousel";

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart, getCartTotal, viewedProducts } = useAppContext();

  return (
    <div className="container mx-auto py-12">
      <h1 className="text-4xl font-headline font-bold mb-8">Your Cart</h1>
      {cart.length === 0 ? (
        <Card className="text-center py-20">
            <ShoppingCartIcon className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
            <Button asChild>
                <Link href="/products">Start Shopping</Link>
            </Button>
        </Card>
      ) : (
        <>
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-0">
                  <ul className="divide-y">
                    {cart.map((item) => {
                      const image = PlaceHolderImages.find(img => img.id === item.imageId);
                      return (
                        <li key={item.id} className="flex items-center p-6">
                          <div className="relative h-24 w-24 rounded-md overflow-hidden mr-6">
                            {image && (
                              <Image
                                src={image.imageUrl}
                                alt={item.name}
                                data-ai-hint={image.imageHint}
                                fill
                                className="object-cover"
                              />
                            )}
                          </div>
                          <div className="flex-grow">
                            <Link href={`/products/${item.id}`} className="font-semibold hover:text-primary">{item.name}</Link>
                            <p className="text-sm text-muted-foreground">${item.price.toFixed(2)}</p>
                          </div>
                          <div className="flex items-center gap-4">
                              <div className="flex items-center border rounded-md">
                                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => updateQuantity(item.id, item.quantity - 1)}>
                                      <Minus className="h-4 w-4" />
                                  </Button>
                                  <Input
                                      type="number"
                                      value={item.quantity}
                                      onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 0)}
                                      className="h-9 w-14 text-center border-0 focus-visible:ring-0"
                                  />
                                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                                      <Plus className="h-4 w-4" />
                                  </Button>
                              </div>
                             <p className="w-24 text-right font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                             <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => removeFromCart(item.id)}>
                                 <Trash2 className="h-5 w-5" />
                             </Button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </CardContent>
              </Card>
            </div>
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${getCartTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>${getCartTotal().toFixed(2)}</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button size="lg" className="w-full">Proceed to Checkout</Button>
                </CardFooter>
              </Card>
            </div>
          </div>
           <div className="mt-24">
             <RecommendationCarousel
                productId={cart[0].id}
                productIdsInCart={cart.map(item => item.id)}
                productIdsViewed={viewedProducts}
                title="You Might Also Need"
              />
          </div>
        </>
      )}
    </div>
  );
}
