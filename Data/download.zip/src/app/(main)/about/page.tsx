import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Target, Bot, Sparkles } from "lucide-react";

export const metadata = {
  title: "About AuraFind",
  description: "Learn about our mission to revolutionize product discovery through AI.",
};

export default function AboutPage() {
  const aboutImage = PlaceHolderImages.find(img => img.id === 'hero-image');

  return (
    <div>
      <section className="relative w-full h-64 bg-primary">
        {aboutImage && (
          <Image
            src={aboutImage.imageUrl}
            alt="Abstract background"
            data-ai-hint="abstract texture"
            fill
            className="object-cover opacity-20"
          />
        )}
        <div className="container mx-auto h-full flex items-center justify-center text-center">
          <h1 className="text-5xl font-headline font-bold text-primary-foreground">About AuraFind</h1>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center">
            <h2 className="text-3xl font-bold font-headline mb-4">Our Mission</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              At AuraFind, we believe shopping should be a journey of discovery, not an endless scroll. Our mission is to seamlessly connect you with products that resonate with your personal style and needs. By harnessing the power of artificial intelligence, we aim to create a smarter, more intuitive, and deeply personal shopping experience for everyone.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 mt-20 text-center">
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary/20 text-primary mb-4">
                <Target className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Personalization</h3>
              <p className="text-muted-foreground">Our AI learns your preferences to suggest products you'll genuinely love.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary/20 text-primary mb-4">
                <Bot className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Smart Technology</h3>
              <p className="text-muted-foreground">We use cutting-edge tech to find patterns and complementary items.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary/20 text-primary mb-4">
                <Sparkles className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Curated Quality</h3>
              <p className="text-muted-foreground">We focus on well-designed, quality products to enhance your life.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
