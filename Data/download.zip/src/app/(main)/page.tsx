import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { categories, products } from "@/lib/data";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import ProductCard from "@/components/product/product-card";
import { ArrowRight } from "lucide-react";

export default function HomePage() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-image');
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative w-full h-[60vh] md:h-[70vh] text-white">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            data-ai-hint={heroImage.imageHint}
            fill
            className="object-cover"
            priority
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative container mx-auto h-full flex flex-col items-center justify-center text-center">
          <h1 className="text-4xl md:text-6xl font-headline font-bold mb-4">Discover Your Style</h1>
          <p className="text-lg md:text-xl max-w-2xl mb-8">Find curated products that match your unique taste, powered by AI.</p>
          <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/products">
              Explore Products <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto">
          <h2 className="text-3xl font-headline font-bold text-center mb-10">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {categories.map((category) => (
              <Link href={`/products?category=${category.id}`} key={category.id} className="group flex flex-col items-center text-center p-4 rounded-lg transition-all duration-300 hover:bg-card hover:shadow-md">
                <div className="mb-4 bg-primary/20 p-5 rounded-full text-primary group-hover:bg-accent group-hover:text-accent-foreground transition-colors duration-300">
                  <category.icon className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold">{category.name}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16 bg-secondary/50">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-3xl font-headline font-bold">Featured Products</h2>
            <Button variant="ghost" asChild>
              <Link href="/products">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
