"use client";

import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAppContext } from "@/context/app-context";
import { getProducts } from "@/lib/data";
import ProductCard from "@/components/product/product-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, User as UserIcon } from "lucide-react";

export default function AccountPage() {
  const { user, likedItems } = useAppContext();
  const router = useRouter();
  const searchParams = useSearchParams();

  const favoriteProducts = getProducts(likedItems);
  const tab = searchParams.get("tab") || "profile";
  
  useEffect(() => {
    if (!user) {
      router.push("/auth/login");
    }
  }, [user, router]);

  if (!user) {
    return (
      <div className="container mx-auto py-12 text-center">
        <p>Redirecting to login...</p>
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  }

  return (
    <div className="container mx-auto py-12">
      <div className="flex flex-col md:flex-row items-center gap-6 mb-12">
        <Avatar className="h-24 w-24">
            <AvatarImage src={`https://avatar.vercel.sh/${user.email}.png`} alt={user.name} />
            <AvatarFallback className="text-3xl">{getInitials(user.name)}</AvatarFallback>
        </Avatar>
        <div>
            <h1 className="text-4xl font-headline font-bold">{user.name}</h1>
            <p className="text-lg text-muted-foreground">{user.email}</p>
        </div>
      </div>
      
      <Tabs value={tab} onValueChange={(value) => router.push(`/account?tab=${value}`)} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="profile">
            <UserIcon className="mr-2 h-4 w-4" /> Profile
          </TabsTrigger>
          <TabsTrigger value="favorites">
            <Heart className="mr-2 h-4 w-4" /> Favorites
          </TabsTrigger>
        </TabsList>
        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="font-semibold">Full Name</p>
                <p className="text-muted-foreground">{user.name}</p>
              </div>
              <div>
                <p className="font-semibold">Email Address</p>
                <p className="text-muted-foreground">{user.email}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="favorites" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Favorite Items</CardTitle>
            </CardHeader>
            <CardContent>
              {favoriteProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {favoriteProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <Heart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Favorites Yet</h3>
                  <p className="text-muted-foreground">Click the heart icon on a product to save it here.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
