"use server";

import { getProductRecommendations, ProductRecommendationInput, ProductRecommendationOutput } from "@/ai/flows/product-recommendation-engine";
import { products } from "@/lib/data";

export async function getRecommendationsAction(input: ProductRecommendationInput): Promise<ProductRecommendationOutput> {
  // In a real app, you would have a database of all product IDs.
  // Here we simulate it by using the mock data.
  // The AI might return IDs that don't exist in our small mock dataset.
  // So, we'll generate some plausible but fake recommendations if the AI fails or returns empty.
  try {
    const aiResult = await getProductRecommendations(input);

    // Filter out IDs that don't exist in our mock product list
    const validRecommendedIds = aiResult.recommendedProductIds.filter(id => products.some(p => p.id === id));
    
    if (validRecommendedIds.length > 0) {
      return { recommendedProductIds: validRecommendedIds };
    }
    
    // Fallback if AI returns no valid recommendations
    return getFallbackRecommendations(input.productId);

  } catch (error) {
    console.error("Error in getRecommendationsAction:", error);
    // Return fallback recommendations on error
    return getFallbackRecommendations(input.productId);
  }
}

function getFallbackRecommendations(currentProductId: string): ProductRecommendationOutput {
    // Simple fallback: return a few products from the same category or just some random ones.
    const currentProduct = products.find(p => p.id === currentProductId);
    const productCategory = currentProduct?.category;

    let fallbackIds = products
      .filter(p => p.id !== currentProductId && p.category === productCategory)
      .map(p => p.id);

    if (fallbackIds.length < 4) {
      fallbackIds = products
        .filter(p => p.id !== currentProductId)
        .map(p => p.id);
    }
    
    // Return up to 8 random items from the list
    const shuffled = fallbackIds.sort(() => 0.5 - Math.random());
    return { recommendedProductIds: shuffled.slice(0, 8) };
}
