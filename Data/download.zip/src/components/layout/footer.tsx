import { AuraFindLogo } from "@/components/icons/logo";
import { Twitter, Instagram, Facebook } from "lucide-react";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between lg:flex-row">
          <div className="flex items-center justify-center lg:justify-start mb-6 lg:mb-0">
            <Link href="/" className="flex items-center space-x-2">
              <AuraFindLogo className="h-8 w-8" />
              <span className="text-xl font-bold">AuraFind</span>
            </Link>
          </div>
          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 mb-6 lg:mb-0" aria-label="Footer">
            <Link href="/about" className="text-sm hover:underline">About</Link>
            <Link href="/contact" className="text-sm hover:underline">Contact</Link>
            <Link href="/products" className="text-sm hover:underline">Products</Link>
          </nav>
          <div className="flex justify-center space-x-6">
            <a href="#" className="text-secondary-foreground hover:text-primary">
              <span className="sr-only">Twitter</span>
              <Twitter className="h-6 w-6" />
            </a>
            <a href="#" className="text-secondary-foreground hover:text-primary">
              <span className="sr-only">Instagram</span>
              <Instagram className="h-6 w-6" />
            </a>
            <a href="#" className="text-secondary-foreground hover:text-primary">
              <span className="sr-only">Facebook</span>
              <Facebook className="h-6 w-6" />
            </a>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} AuraFind. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
