"use client";

import Image from 'next/image';
import Link from 'next/link';
import type { Product } from '@/lib/types';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import { Heart, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import Rating from '@/components/product/rating';
import { useAppContext } from '@/context/app-context';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart, toggleLike, isLiked } = useAppContext();
  const image = PlaceHolderImages.find(img => img.id === product.imageId);

  const handleLikeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleLike(product.id);
  };

  const handleCartClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <Card className="flex h-full flex-col overflow-hidden transition-shadow duration-300 hover:shadow-lg">
      <CardHeader className="p-0">
        <Link href={`/products/${product.id}`} className="block">
          <div className="aspect-square overflow-hidden relative">
            {image && (
              <Image
                src={image.imageUrl}
                alt={product.name}
                data-ai-hint={image.imageHint}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
            )}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-9 w-9 rounded-full bg-background/70 hover:bg-background"
              onClick={handleLikeClick}
              aria-label={isLiked(product.id) ? "Unlike" : "Like"}
            >
              <Heart className={cn("h-5 w-5", isLiked(product.id) ? "fill-red-500 text-red-500" : "text-muted-foreground")} />
            </Button>
          </div>
        </Link>
      </CardHeader>
      <CardContent className="flex-grow p-4">
        <Link href={`/products/${product.id}`}>
          <CardTitle className="mb-1 text-lg font-semibold leading-tight hover:text-primary">
            {product.name}
          </CardTitle>
        </Link>
        <div className="mt-1">
          <Rating rating={product.rating} />
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between p-4 pt-0">
        <p className="text-xl font-bold text-primary">${product.price.toFixed(2)}</p>
        <Button size="sm" onClick={handleCartClick}>
          <ShoppingCart className="mr-2 h-4 w-4" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}
