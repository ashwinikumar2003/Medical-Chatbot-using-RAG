"use client";

import { useEffect } from 'react';
import type { Product } from '@/lib/types';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Heart, ShoppingCart } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useAppContext } from '@/context/app-context';
import Rating from '@/components/product/rating';
import { cn } from '@/lib/utils';
import RecommendationCarousel from './recommendation-carousel';

export default function ProductDetailClient({ product }: { product: Product }) {
  const { addToCart, toggleLike, isLiked, addViewedProduct, cart, viewedProducts } = useAppContext();
  const image = PlaceHolderImages.find(img => img.id === product.imageId);

  useEffect(() => {
    addViewedProduct(product.id);
  }, [product.id, addViewedProduct]);

  return (
    <div className="container mx-auto py-12">
      <div className="grid md:grid-cols-2 gap-12">
        {/* Image Gallery */}
        <div className="aspect-square relative rounded-lg overflow-hidden shadow-lg">
          {image && (
            <Image
              src={image.imageUrl}
              alt={product.name}
              data-ai-hint={image.imageHint}
              fill
              className="object-cover"
            />
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <h1 className="text-3xl lg:text-4xl font-bold font-headline mb-2">{product.name}</h1>
          <div className="flex items-center gap-4 mb-4">
             <Rating rating={product.rating} />
             <span className="text-sm text-muted-foreground">{product.rating.toFixed(1)} stars</span>
          </div>
          <p className="text-3xl font-bold text-primary mb-6">${product.price.toFixed(2)}</p>
          
          <p className="text-muted-foreground leading-relaxed mb-8">{product.description}</p>

          <Separator className="my-4" />

          {/* Actions */}
          <div className="flex items-center gap-4 mb-8">
            <Button size="lg" className="flex-1" onClick={() => addToCart(product)}>
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="px-4"
              onClick={() => toggleLike(product.id)}
              aria-label={isLiked(product.id) ? "Unlike" : "Like"}
            >
              <Heart className={cn("h-6 w-6", isLiked(product.id) ? "fill-red-500 text-red-500" : "text-muted-foreground")} />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Recommendations Section */}
      <div className="mt-24">
         <RecommendationCarousel 
            productId={product.id} 
            productIdsInCart={cart.map(item => item.id)}
            productIdsViewed={viewedProducts}
          />
      </div>
    </div>
  );
}
