"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/lib/types";
import { getProducts } from "@/lib/data";
import { getRecommendationsAction } from "@/app/lib/actions";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import ProductCard from "./product-card";
import { Skeleton } from "@/components/ui/skeleton";

interface RecommendationCarouselProps {
  productId: string;
  productIdsInCart: string[];
  productIdsViewed: string[];
  title?: string;
}

export default function RecommendationCarousel({ productId, productIdsInCart, productIdsViewed, title = "You Might Also Like" }: RecommendationCarouselProps) {
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecommendations = async () => {
      setLoading(true);
      try {
        const result = await getRecommendationsAction({
          productId,
          productIdsInCart,
          productIdsViewed,
        });
        
        if (result && result.recommendedProductIds) {
          // Filter out the current product from recommendations
          const filteredIds = result.recommendedProductIds.filter(id => id !== productId && !productIdsInCart.includes(id));
          const recommendedProducts = getProducts(filteredIds);
          setRecommendations(recommendedProducts);
        }
      } catch (error) {
        console.error("Failed to fetch recommendations:", error);
        setRecommendations([]);
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, [productId, productIdsInCart, productIdsViewed]);

  if (loading) {
    return (
      <div>
        <h2 className="text-3xl font-headline font-bold mb-6">{title}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex flex-col space-y-3">
              <Skeleton className="h-[250px] w-full rounded-lg" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (recommendations.length === 0) {
    return null;
  }

  return (
    <div>
      <h2 className="text-3xl font-headline font-bold mb-6">{title}</h2>
      <Carousel
        opts={{
          align: "start",
          loop: true,
        }}
        className="w-full"
      >
        <CarouselContent>
          {recommendations.map((product) => (
            <CarouselItem key={product.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
              <div className="p-1">
                <ProductCard product={product} />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="ml-12" />
        <CarouselNext className="mr-12" />
      </Carousel>
    </div>
  );
}
