'use server';

/**
 * @fileOverview AI-powered product recommendation engine.
 *
 * - getProductRecommendations - A function that takes a product ID and returns a list of recommended product IDs.
 * - ProductRecommendationInput - The input type for the getProductRecommendations function.
 * - ProductRecommendationOutput - The return type for the getProductRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProductRecommendationInputSchema = z.object({
  productId: z.string().describe('The ID of the product to get recommendations for.'),
  productIdsInCart: z.array(z.string()).optional().describe('List of product IDs currently in the cart.'),
  productIdsViewed: z.array(z.string()).optional().describe('List of recently viewed product IDs.'),
});
export type ProductRecommendationInput = z.infer<typeof ProductRecommendationInputSchema>;

const ProductRecommendationOutputSchema = z.object({
  recommendedProductIds: z.array(z.string()).describe('A list of recommended product IDs.'),
});
export type ProductRecommendationOutput = z.infer<typeof ProductRecommendationOutputSchema>;

export async function getProductRecommendations(input: ProductRecommendationInput): Promise<ProductRecommendationOutput> {
  return productRecommendationEngineFlow(input);
}

const prompt = ai.definePrompt({
  name: 'productRecommendationPrompt',
  input: {schema: ProductRecommendationInputSchema},
  output: {schema: ProductRecommendationOutputSchema},
  prompt: `You are a product recommendation engine for an e-commerce website.
  Given a product ID, a list of product IDs in the cart, and a list of recently viewed product IDs,
  recommend other product IDs that the user might be interested in.

  Product ID: {{{productId}}}
  Product IDs in Cart: {{#if productIdsInCart}}{{{productIdsInCart}}}{{else}}None{{/if}}
  Product IDs Viewed: {{#if productIdsViewed}}{{{productIdsViewed}}}{{else}}None{{/if}}

  Return only a list of product IDs in the recommendedProductIds field.
  Do not include any other text or explanation.`,
});

const productRecommendationEngineFlow = ai.defineFlow(
  {
    name: 'productRecommendationEngineFlow',
    inputSchema: ProductRecommendationInputSchema,
    outputSchema: ProductRecommendationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
