import { config } from 'dotenv';
config();

import '@/ai/flows/product-recommendation-engine.ts';